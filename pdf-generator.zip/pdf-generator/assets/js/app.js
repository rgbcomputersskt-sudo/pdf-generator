const form = document.getElementById("pdfForm");
const previewType = document.getElementById("previewType");
const previewTitle = document.getElementById("previewTitle");
const previewSubtitle = document.getElementById("previewSubtitle");
const previewRef = document.getElementById("previewRef");
const previewDate = document.getElementById("previewDate");
const previewRecipient = document.getElementById("previewRecipient");
const previewContent = document.getElementById("previewContent");
const previewHighlights = document.getElementById("previewHighlights");
const previewFooter = document.getElementById("previewFooter");
const previewSheet = document.getElementById("pdfPreview");
const generateBtn = document.getElementById("generateBtn");
const sampleBtn = document.getElementById("sampleBtn");
const sampleBtnTop = document.getElementById("sampleBtnTop");
const resetBtn = document.getElementById("resetBtn");
const resetBtnPreview = document.getElementById("resetBtnPreview");
const statusMessage = document.getElementById("statusMessage");

const fields = {
  documentType: document.getElementById("documentType"),
  documentTitle: document.getElementById("documentTitle"),
  subtitle: document.getElementById("subtitle"),
  recipientName: document.getElementById("recipientName"),
  referenceNumber: document.getElementById("referenceNumber"),
  documentDate: document.getElementById("documentDate"),
  accentColor: document.getElementById("accentColor"),
  content: document.getElementById("content"),
  highlights: document.getElementById("highlights"),
  footerNote: document.getElementById("footerNote"),
};

const defaultSample = {
  documentType: "Proposal",
  documentTitle: "Website Redesign Proposal",
  subtitle: "A streamlined approach to improve usability, branding, and conversions.",
  recipientName: "Operations Team",
  referenceNumber: "CV-2026-001",
  documentDate: getTodayValue(),
  accentColor: "#1dd3b0",
  content: `Creative Vision Information Technology delivers modern digital experiences that are built for clarity, speed, and measurable results.

This proposal outlines a responsive website refresh designed to elevate the brand, improve customer engagement, and simplify future content updates.`,
  highlights: `Responsive Bootstrap layout
Live PDF preview and export
Editable business content blocks
Professional document footer and branding`,
  footerNote: `This document can be customized for client proposals, quotations, contracts, and internal reports.`,
};

function getTodayValue() {
  return new Date().toISOString().split("T")[0];
}

function formatDisplayDate(value) {
  if (!value) {
    return new Intl.DateTimeFormat("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
    }).format(new Date());
  }

  const date = new Date(`${value}T00:00:00`);
  return new Intl.DateTimeFormat("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

function slugify(value) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "") || "creative-vision-document";
}

function normalizeLines(text) {
  return text
    .split(/\n+/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => line.replace(/^[-*•]\s*/, ""));
}

function setStatus(message, type = "") {
  statusMessage.textContent = message;
  statusMessage.classList.remove("is-success", "is-error");

  if (type) {
    statusMessage.classList.add(`is-${type}`);
  }
}

function updateAccent(color) {
  document.documentElement.style.setProperty("--preview-accent", color);
}

function renderPreview() {
  previewType.textContent = fields.documentType.value || defaultSample.documentType;
  previewTitle.textContent = fields.documentTitle.value.trim() || "Creative document title";
  previewSubtitle.textContent = fields.subtitle.value.trim() || "Subtitle / executive summary";
  previewRef.textContent = fields.referenceNumber.value.trim() || defaultSample.referenceNumber;
  previewDate.textContent = formatDisplayDate(fields.documentDate.value || getTodayValue());
  previewRecipient.textContent = fields.recipientName.value.trim() || "Recipient";

  const paragraphs = normalizeLines(fields.content.value);
  const highlights = normalizeLines(fields.highlights.value);
  const footerText = fields.footerNote.value.trim();

  previewContent.replaceChildren();
  if (paragraphs.length === 0) {
    const emptyParagraph = document.createElement("p");
    emptyParagraph.className = "pdf-paragraph text-muted";
    emptyParagraph.textContent = "Add content to see it rendered in the preview.";
    previewContent.appendChild(emptyParagraph);
  } else {
    paragraphs.forEach((paragraphText) => {
      const paragraph = document.createElement("p");
      paragraph.className = "pdf-paragraph";
      paragraph.textContent = paragraphText;
      previewContent.appendChild(paragraph);
    });
  }

  previewHighlights.replaceChildren();
  if (highlights.length === 0) {
    const emptyItem = document.createElement("li");
    emptyItem.textContent = "Add one highlight per line to render bullet points here.";
    previewHighlights.appendChild(emptyItem);
  } else {
    highlights.forEach((itemText) => {
      const listItem = document.createElement("li");
      listItem.textContent = itemText;
      previewHighlights.appendChild(listItem);
    });
  }

  previewFooter.textContent = footerText || "Footer content appears here.";
  updateAccent(fields.accentColor.value || defaultSample.accentColor);
}

function applySampleData() {
  fields.documentType.value = defaultSample.documentType;
  fields.documentTitle.value = defaultSample.documentTitle;
  fields.subtitle.value = defaultSample.subtitle;
  fields.recipientName.value = defaultSample.recipientName;
  fields.referenceNumber.value = defaultSample.referenceNumber;
  fields.documentDate.value = defaultSample.documentDate;
  fields.accentColor.value = defaultSample.accentColor;
  fields.content.value = defaultSample.content;
  fields.highlights.value = defaultSample.highlights;
  fields.footerNote.value = defaultSample.footerNote;
  renderPreview();
  setStatus("Sample content loaded.", "success");
}

async function generatePdf() {
  if (typeof html2pdf === "undefined") {
    setStatus("PDF library failed to load. Check your internet connection or CDN availability.", "error");
    return;
  }

  const title = fields.documentTitle.value.trim() || "creative-vision-document";
  const dateStamp = fields.documentDate.value || getTodayValue();
  const filename = `${slugify(title)}-${dateStamp}.pdf`;
  const originalLabel = generateBtn.textContent;

  try {
    generateBtn.disabled = true;
    generateBtn.textContent = "Generating...";
    setStatus("Generating PDF file...");

    await html2pdf()
      .set({
        margin: [8, 8, 10, 8],
        filename,
        image: { type: "jpeg", quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true, letterRendering: true, backgroundColor: null },
        jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
        pagebreak: { mode: ["avoid-all", "css", "legacy"] },
      })
      .from(previewSheet)
      .save();

    setStatus(`PDF downloaded as ${filename}.`, "success");
  } catch (error) {
    console.error(error);
    setStatus("PDF generation failed. Please try again.", "error");
  } finally {
    generateBtn.disabled = false;
    generateBtn.textContent = originalLabel;
  }
}

function bindFieldEvents() {
  Object.values(fields).forEach((field) => {
    field.addEventListener("input", () => {
      renderPreview();
      setStatus("Preview updated.");
    });
  });
}

function init() {
  fields.documentDate.value = defaultSample.documentDate;
  applySampleData();
  bindFieldEvents();

  sampleBtn.addEventListener("click", applySampleData);
  sampleBtnTop.addEventListener("click", applySampleData);
  resetBtn.addEventListener("click", applySampleData);
  resetBtnPreview.addEventListener("click", applySampleData);
  generateBtn.addEventListener("click", generatePdf);

  form.addEventListener("submit", (event) => event.preventDefault());
}

document.addEventListener("DOMContentLoaded", init);
